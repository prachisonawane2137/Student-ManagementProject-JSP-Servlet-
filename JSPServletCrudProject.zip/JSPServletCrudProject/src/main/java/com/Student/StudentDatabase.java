package com.Student;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class StudentDatabase {

	public static Connection getConnection() {
		Connection con = null;

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student1", "root", "Prachis2137");

		} catch (Exception e) {
			e.printStackTrace();
		}
		return con;

	}

	public static void addStudent(Student s) {
		try (Connection con = getConnection())

		{
			PreparedStatement ps = con.prepareStatement("INSERT INTO studtbl(name,email,course)VALUES(?,?,?)");

			ps.setString(1, s.getName());
			ps.setString(2, s.getEmail());
			ps.setString(3, s.getCourse());
			ps.executeUpdate();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static List<Student> getAllStudents() {
	    List<Student> list = new ArrayList<>();

	    try (Connection con = getConnection();
	         Statement stmt = con.createStatement();
	         ResultSet rs = stmt.executeQuery("SELECT * FROM studtbl")) {

	        while (rs.next()) {
	            Student s = new Student();
	            s.setId(rs.getInt("id"));
	            s.setName(rs.getString("name"));
	            s.setEmail(rs.getString("email"));
	            s.setCourse(rs.getString("course"));
	            list.add(s);
	        }

	    } catch (Exception e) {
	        e.printStackTrace();
	    }

	    return list;
	}


	public static Student getStudentById(int id) {

		Student s = new Student();

		try (Connection con = getConnection();
				PreparedStatement ps = con.prepareStatement("SELECT * FROM studtbl WHERE id=?")) {
			ps.setInt(1, id);

			ResultSet rs = ps.executeQuery();

			while (rs.next()) {

				s.setId(rs.getInt("id"));
				s.setName(rs.getString("name"));
				s.setEmail(rs.getString("email"));
				s.setCourse(rs.getString("course"));

			}
		}

		catch (Exception e) {
			e.printStackTrace();
		}

		return s;

	}

	public static void updateStudent(Student s) {
		try (Connection con = getConnection();
				PreparedStatement ps = con
						.prepareStatement("UPDATE studtbl SET name = ?, email = ?, course = ? WHERE id = ?")) {

			ps.setString(1, s.getName());
			ps.setString(2, s.getEmail());
			ps.setString(3, s.getCourse());
			ps.setInt(4, s.getId()); // Now 'id' is used correctly in WHERE clause

			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	public static void DeleteStudent(int id) {

		try (Connection con = getConnection();
				PreparedStatement ps = con.prepareStatement("DELETE  FROM studtbl WHERE id=?")) {

			ps.setInt(1, id);
			ps.executeUpdate();

		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
